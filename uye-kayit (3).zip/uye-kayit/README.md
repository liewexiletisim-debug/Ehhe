# Üye Kayıt

## 1. Supabase (proje: Uyekayid)
Tablolar kuruldu ve `www/config.js` dolduruldu. Geriye sadece:
1. **Authentication → Providers → Email**: "Allow new users to sign up" seçeneğini **kapat**.
2. **Authentication → Users → Add user**: kendi e-posta/şifreni oluştur ("Auto confirm" işaretli olsun).

(Sıfırdan kurulum gerekirse `supabase/schema.sql` dosyasını SQL Editor'de çalıştır.)

## 2. APK
1. Klasörü GitHub'a yükle (main branch).
2. Actions → "Build APK" otomatik çalışır.
3. Artifacts → uye-kayit-apk → app-debug.apk'yı telefona kur.

## Notlar
- Veriler artık bulutta; uygulama silinse de kaybolmaz. İnternet gerekir.
- Eski (yerel) veri varsa girişten sonra "Buluta aktar" kartı çıkar.
- Her kullanıcı sadece kendi eklediği kayıtları görür. Ekibin ortak görmesi gerekirse RLS policy'leri değiştirilmelidir.
- `www/supabase.js` = @supabase/supabase-js 2.45.4 (UMD), elle güncellenir.

## Otomatik güncelleme
- Her `push` yeni bir APK derler ve GitHub'da **Releases**'e koyar (v1, v2, ...).
- Uygulama açılışta son release'e bakar; yeni sürüm varsa üstte "Yeni sürüm var" çubuğu çıkar. Dokun → APK iner → Kur.
- Çalışması için depo **Public** olmalı.
- Güncelleme üstüne kurulabilsin diye APK her seferinde `debug.keystore` ile imzalanır. Bu dosyayı silme/değiştirme.
- Daha güvenli seçenek: `debug.keystore` dosyasını base64'leyip `KEYSTORE_B64` adıyla GitHub Secrets'a ekle (workflow önce onu kullanır). İmza değişeceği için bir kez kaldırıp yeniden kurman gerekir.
