// GitHub Actions derleme sırasında bu dosyayı otomatik üzerine yazar.
window.APP_VERSION = 0;
window.APP_REPO = '';
