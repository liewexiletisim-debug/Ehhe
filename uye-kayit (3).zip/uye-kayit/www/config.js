// Supabase > Project Settings > API sayfasından al.
// anon/publishable key herkese açık olacak şekilde tasarlanmıştır; güvenliği RLS sağlar.
// service_role anahtarını ASLA buraya koyma.
window.APP_CONFIG = {
  url: 'https://fdfdnveslzlvkpmajwmn.supabase.co',
  anonKey: 'sb_publishable_zQdDdQ3gfZgIu6oJXZvsjQ_pcFiOfXg'
};
